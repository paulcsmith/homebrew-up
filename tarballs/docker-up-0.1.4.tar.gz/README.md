# Where Up's homebrew formula lives

## How to release a new version

* Update `shard.yml` to the version of Up you want to release.
* Run `bin/generate`
* Tag it `git tag vX.X.X`
* Push it up. Remember to push the tags `git push --tags`
