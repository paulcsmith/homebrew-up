class DockerUp < Formula
  desc "Tool for local developement with Docker"
  homepage "http://github.com/paulcsmith/up"
  url "https://github.com/paulcsmith/homebrew-up/raw/master/tarballs/docker-up-0.1.4.tar.gz"
  sha256 "fb31d189f632b18161eb7425340eebc5b5aba134116c67acf5885758b7417a0b"
  version "0.1.4"
  depends_on "crystal-lang"

  def install
    system "ls"
    system "echo ls"
    system "echo $PWD"
    system "crystal build lib/up/src/run.cr -o up"
    bin.install "up"
  end

  test do
    system "{bin}/up", "--help"
  end
end
