class DockerUp < Formula
  desc "Tool for local docker developement"
  homepage "http://github.com/paulcsmith/up"
  url "https://github.com/paulcsmith/homebrew-up/raw/master/tarballs/docker-up-0.1.1.tar.gz"
  sha256 "e591c2047d1d4c82e983ddc977d1248387f1a78d091c9180477fcdd6ad862ea6"
  version "0.1.1"
  depends_on "crystal-lang"

  def install
    system "mkdir lib"
    system "ls"
    system "mv ./* lib/"
    system "crystal build lib/up/src/run.cr -o up"
    bin.install "up"
  end

  test do
    system "{bin}/up", "--help"
  end
end
