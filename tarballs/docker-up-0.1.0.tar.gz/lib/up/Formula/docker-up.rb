class DockerUp < Formula
  desc "Tool for working with Docker locally"
  homepage "http://github.com/paulcsmith/up"
  url "https://github.com/paulcsmith/up/raw/master/tarballs/up-0.1.0.tar.gz"
  sha256 "e1d5b995f2ed474cfd71d27c41bf6852d56b875fecaf1cb1f4d67744f068cb09"
  version "0.1.0"
  depends_on "crystal-lang"

  def install
    system "shards install"
    system "crystal build src/run.cr -o up"
    bin.install "up"
  end

  test do
    system "{bin}/up", "--help"
  end
end
